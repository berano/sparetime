import sys
import re
import urllib
import urllib2
import cookielib
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmc
from BeautifulSoup import BeautifulSoup


vhd = xbmcaddon.Addon(id='plugin.video.veehd')
pluginhandle = int(sys.argv[1])


def cats():
    addDir('Channels', 'http', 1, '')
    addDir('Dashboard', 'http', 1, '')
    addDir('Popular', 'http://veehd.com/popular', 2, '')
    addDir('Recent', 'http://veehd.com/recent', 2, '')
    addDir('Bookmarks', 'http://veehd.com/bookmarks', 2, '')
    addDir('Search', 'http://veehd.com/', 4, '')

def chans(url, self_tags):
    tags = ['Animation', 'Comedy', 'Film', 'Games', 'Music', 'Other']
    if self_tags:
        tags.extend([tag.strip().capitalize() for tag in self_tags])
    tags.sort()
    for tag in tags:
        addDir(tag, 'http://veehd.com/search?tag=%s' % (tag.lower()), 2, '')

def dash(url):
    addDir('Timeline', 'http://veehd.com/timeline?f=va', 2, '')
    addDir('Friends', 'http://veehd.com/dashboard?f=fva', 2, '')
    addDir('Private', 'http://veehd.com/dashboard?f=pri', 2, '')

def get_content(url):
    urlogin = 'http://veehd.com/login'
    cookiejar = cookielib.LWPCookieJar()
    if vhd.getSetting('adult'):
        cookiejar.set_cookie(cookielib.Cookie(
            version=0, name='nsfw', value='1',
            port=None, port_specified=False, domain='veehd.com',
            domain_specified=False, domain_initial_dot=False, path='/',
            path_specified=True, secure=False, expires=None, discard=True,
            comment=None, comment_url=None, rest={'HttpOnly': None},
            rfc2109=False))
    cookiejar = urllib2.HTTPCookieProcessor(cookiejar)
    opener = urllib2.build_opener(cookiejar)
    urllib2.install_opener(opener)
    values = {'ref': 'http://veehd.com/', 'uname': uname,
              'pword': pwd, 'submit': 'Login', 'terms': 'on'}
    user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    headers = {'User-Agent': user_agent}
    data = urllib.urlencode(values)
    req = urllib2.Request(urlogin, data, headers)
    response = urllib2.urlopen(req)
    req = urllib2.Request(url)
    req.add_header('User-Agent', user_agent)
    response = urllib2.urlopen(req)
    return response

def index(url, category):
    soup = BeautifulSoup(get_content(url).read())
    video = soup.find('table', attrs={'class': 'movieList'})
    while video:
        try:
            video = video.findNext('a', attrs={'class': 'movieLink'})
            thumb = video("img")[0]["src"]
            thumb = thumb.replace('https','http')
            vurl = video["href"]
            video = video.findNext('a')
            vname = video.string
            if category == "Bookmarks":
                temp = video.findNext('span')
                if re.search("private", temp.string):
                    temp = temp.findNext('span')
                if temp.text == "nsfw":
                    vname = '[COLOR FFFF0000]%s[/COLOR]' % (vname,)
                    temp = temp.findNext('span')
                plot = temp.string
                item = xbmcgui.ListItem(vname, iconImage=thumb)
                item.setInfo(type="Video",
                        infoLabels={"Title": vname,
                                    "Plot": plot
                                    }
                        )
            else:
                video = video.findNext('span', attrs={'class': "userTag"})
                video = video.findNext('span')
                if video.text == "nsfw":
                    vname = '[COLOR FFFF0000]%s[/COLOR]' % (vname,)
                    video = video.findNext('span')
                plot = video.string
                video = video.findNext('span', attrs={'class': "dr"})
                duration = [int(x) for x in video.string.split(":")]
                duration_min = (duration[0] * 60) + duration[1]
                video = video.findNext('span', attrs={'class': "dr"})
                size = video.string
                item = xbmcgui.ListItem(vname, iconImage=thumb)
                item.setInfo(type="Video",
                        infoLabels={"Title": vname,
                                    "Plot": plot,
                                    "Duration": duration_min,
                                    "Size": size
                                    }
                        )
            xbmcurl = "%s?url=http://veehd.com%s&mode=3" % (sys.argv[0], vurl)
            item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(handle=pluginhandle,
                    url=xbmcurl, listitem=item)
        except:
            pass
    try:
        page_class = soup.find('div', attrs={'class': 'pagination'})
        current = page_class.find('li', attrs={'class': 'currentpage'}).text
        pages = page_class.findAll('li', attrs={'class': 'nextpage'})
        for i in pages:
            if i("a")[0]["href"][-1] > current:
                nextpage = i("a")[0]["href"]
        addDir('Next page', 'http://veehd.com%s' % (nextpage), 2, '')
    except:
        pass


def index_dash(url):
    soup = BeautifulSoup(get_content(url).read())
    timeline = soup.findAll("span", attrs={"class": "tlComment"})
    for tag in timeline:
        thumb = tag("img")[0]["src"]
        thumb = thumb.replace('https','http')
        url = tag("a")[0]["href"]
        name = tag("a")[0].text.strip()
        xbmcurl = "%s?url=http://veehd.com%s&mode=3" % (sys.argv[0], url)
        item = xbmcgui.ListItem(name, iconImage=thumb)
        item.setInfo(type="Video", infoLabels={"Title": name, "Plot": tag.text})
        item.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=pluginhandle, url=xbmcurl,
            listitem=item)


def video(url):
    response = get_content(url)
    vpi = re.compile('"/vpi.+?h=(.+?)"').findall(response.read())[0]
    req = urllib2.Request('http://veehd.com/vpi?h=' + vpi)
    user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    req.add_header('User-Agent', user_agent)
    response = urllib2.urlopen(req)
    link=response.read()

    if re.compile('application/x-shockwave-flash').findall(link):
        finalurl = urllib.unquote(re.compile('"url":"(.+?)"').findall(link)[0])
	print finalurl
    elif re.compile('/va/va').findall(link): 
	#Advertisement scrapped
    	adv = re.compile('"/va/va.+?cb=(.+?)"').findall(link)[0]
    	req = urllib2.Request('http://veehd.com/va/va-free.php?cb=' + adv)
    	user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
    	req.add_header('User-Agent', user_agent)
    	response = urllib2.urlopen(req)
    	link2=response.read()
    elif re.compile('video/divx').findall(link):
        finalurl = re.compile('type="video/divx" src="(.+?)"').findall(link)[0]
        finalurl = urllib.unquote(finalurl)    
    item = xbmcgui.ListItem(path=finalurl)
    xbmcplugin.setResolvedUrl(pluginhandle, True, item)



def search():
    keyb = xbmc.Keyboard('', 'Search VEEHD')
    keyb.doModal()
    if (keyb.isConfirmed()):
        encode = urllib.quote(keyb.getText())
        response = get_content('http://veehd.com/search?q=' + encode)
        soup = BeautifulSoup(response.read())
        video = soup.find('table', attrs={'class': 'movieList'})
        while video:
            try:
                video = video.findNext('a', attrs={'class': 'movieLink'})
                thumb = video("img")[0]["src"]
                thumb = thumb.replace('https','http')
                url = video["href"]
                video = video.findNext('a')
                name = video.string
                video = video.findNext('span', attrs={'class': "userTag"})
                video = video.findNext('span')
                if video.text == "nsfw":
                    name = '[COLOR FFFF0000]%s[/COLOR]' % (name,)
                    video = video.findNext('span')
                plot = video.string
                video = video.findNext('span', attrs={'class': "dr"})
                duration = [int(x) for x in video.string.split(":")]
                duration_min = (duration[0] * 60) + duration[1]
                video = video.findNext('span', attrs={'class': "dr"})
                size = video.string
                pre = sys.argv[0]
                xbmcurl = "%s?url=http://veehd.com%s&mode=3" % (pre, url)
                item = xbmcgui.ListItem(name, iconImage=thumb)
                item.setInfo(type="Video", infoLabels={"Title": name,
                    "Plot": plot, "Duration": duration_min, "Size": size})
                item.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(handle=pluginhandle,
                        url=xbmcurl, listitem=item)
            except:
                pass
        try:
            p_class = soup.find('div', attrs={'class': 'pagination'})
            current = p_class.find('li', attrs={'class': 'currentpage'}).text
            pages = p_class.findAll('li', attrs={'class': 'nextpage'})
            for i in pages:
                if i("a")[0]["href"][-1] > current:
                    nextpage = i("a")[0]["href"]
            addDir('Next page', 'http://veehd.com%s' % (nextpage), 2, '')
        except:
            pass
    return


def get_params(pstring):
    param = {}
    if pstring.endswith('/'):
        pstring.rstrip('/')
    param_pairs = [x.split('=') for x in pstring.lstrip('?').split('&')]
    for key, value in param_pairs:
        if key == "mode":
            value = int(value)
        elif key == "url":
            if len(value) > 1:
                value = str(urllib.unquote_plus(value))
            else:
                value = None
        param[key] = value
    return param


def addDir(name, url, mode, thumbnail):
    u = "%s?url=%s&mode=%s&name=%s" % (sys.argv[0], urllib.quote_plus(url),
                                       mode, urllib.quote_plus(name))
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png",
            thumbnailImage=thumbnail)
    liz.setInfo("video", {"Title": name})
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u,
                                     listitem=liz, isFolder=True)

    return ok


def check_settings(uname, pwd):
    if not uname or not pwd:
        dialog = xbmcgui.Dialog()
        dialog.ok('Welcome to veehd.com',
             'To start using this plugin first go to veehd.com',
             'and create an (free) account.')

        vhd.openSettings(sys.argv[0])

params = {}
if len(sys.argv[2]) >= 2:
    params = get_params(sys.argv[2])

url = None
name = None
mode = None


uname = vhd.getSetting('uname')
pwd = vhd.getSetting('pwd')
tags = vhd.getSetting('tags')

check_settings(uname, pwd)

if 'url' in params:
    url = params['url']
if 'name' in params:
    name = params['name']
if 'mode' in params:
    mode = params['mode']

# print "Mode: %s" % (mode)
# print "URL : %s" % (url)
# print "Name: %s" % (name)

if mode == None or url == None:
    cats()

elif mode == 1:
    if name == 'Dashboard':
        dash(url)
    else:
        if tags:
            taglist = tags.split(',')
        else:
            taglist = []
        chans(url, taglist)
elif mode == 2:
    if re.search('Friends|Private|Timeline', name):
        index_dash(url)
    else:
        index(url, name)
elif mode == 3:
    video(url)
elif mode == 4:
    search()

xbmcplugin.endOfDirectory(pluginhandle)
